const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Guardar datos en usuarios.csv
app.post('/guardar-usuario', (req,res)=>{
  const { nombre,email,password,actividad,gustos,direccion } = req.body;
  if(!nombre || !email || !password || !actividad || !gustos || !direccion){
    return res.status(400).send('Faltan datos');
  }

  const fila = `${nombre},${email},${password},${actividad},${gustos},${direccion}\n`;

  fs.appendFile(path.join(__dirname,'usuarios.csv'),fila,err=>{
    if(err){
      console.error('Error al guardar:',err);
      return res.status(500).send('Error al guardar usuario');
    }
    // En vez de enviar texto plano, enviamos la ruta de logged.html
    res.json({ redirect: '/logged.html', user: { nombre,email,actividad,gustos,direccion } });
  });
});

// Servir landing page explícitamente
app.get('/', (req,res)=> res.sendFile(path.join(__dirname,'public','index.html')));

app.listen(PORT,()=> console.log(`Servidor corriendo en http://localhost:${PORT}`));
